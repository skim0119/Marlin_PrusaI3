#### Developed by Kristian Sloth Lauszus, 2012

The code is released under the GNU General Public License.
_________

This content is needed so it's compatible with the Arduino IDE 1.5.x.

For more information see the following sites: [http://www.arduino.cc/en/Guide/Environment#thirdpartyhardware](http://www.arduino.cc/en/Guide/Environment#thirdpartyhardware) and [http://code.google.com/p/arduino/wiki/Platforms1](http://code.google.com/p/arduino/wiki/Platforms1)
or send me an email at <a href="mailto:lauszus@gmail.com?Subject=Sanguino">lauszus@gmail.com</a>.